import { useEffect, useState } from "react"
import axios from "axios"
import CameraTile from "../components/CameraTile"

export default function Dashboard() {
  const [cameras, setCameras] = useState<any[]>([])

  useEffect(() => {
    const fetchCameras = async () => {
      const token = localStorage.getItem("token")
      const res = await axios.get("http://localhost:3000/api/cameras", {
        headers: { Authorization: `Bearer ${token}` },
      })
      setCameras(res.data)
    }
    fetchCameras()
  }, [])

  return (
    <div className="p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {cameras.map((cam) => (
        <CameraTile key={cam.id} camera={cam} />
      ))}
    </div>
  )
}
