type Props = {
  camera: { id: string; name: string; location?: string }
}

export default function CameraTile({ camera }: Props) {
  return (
    <div className="bg-white rounded shadow p-4 flex flex-col">
      <h3 className="font-bold">{camera.name}</h3>
      <p className="text-sm text-gray-500">{camera.location}</p>
      <div className="mt-2 bg-black text-white h-40 flex items-center justify-center">
        [Video Stream Placeholder]
      </div>
      <div className="flex gap-2 mt-2">
        <button className="flex-1 bg-green-600 text-white py-1 rounded">
          Start
        </button>
        <button className="flex-1 bg-red-600 text-white py-1 rounded">
          Stop
        </button>
      </div>
    </div>
  )
}
