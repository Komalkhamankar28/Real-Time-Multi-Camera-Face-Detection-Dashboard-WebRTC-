package main

import (
    "bytes"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "os"
    "time"

    "github.com/gin-gonic/gin"
    "github.com/google/uuid"
    "github.com/joho/godotenv"
)

type Camera struct {
    ID      string `json:"id"`
    Name    string `json:"name"`
    RtspUrl string `json:"rtspUrl"`
}

type Alert struct {
    ID         string `json:"id"`
    CameraID   string `json:"cameraId"`
    Timestamp  string `json:"timestamp"`
    BboxJson   string `json:"bboxJson"`
    SnapshotUrl string `json:"snapshotUrl"`
}

func loadEnv() {
    if err := godotenv.Load(); err != nil {
        log.Println("No .env file found, using system env variables")
    }
}

func simulateFaceDetection(camera Camera) {
    ticker := time.NewTicker(10 * time.Second) // simulate detection every 10s
    for range ticker.C {
        alert := Alert{
            ID:         uuid.New().String(),
            CameraID:   camera.ID,
            Timestamp:  time.Now().Format(time.RFC3339),
            BboxJson:   `{"x":100,"y":50,"w":80,"h":80}`,
            SnapshotUrl: "",
        }

        payload, _ := json.Marshal(alert)
        backendURL := os.Getenv("BACKEND_URL") + "/api/alerts/" + camera.ID
        req, _ := http.NewRequest("POST", backendURL, bytes.NewBuffer(payload))
        req.Header.Set("Content-Type", "application/json")
        req.Header.Set("Authorization", "Bearer "+os.Getenv("API_TOKEN"))

        client := &http.Client{}
        resp, err := client.Do(req)
        if err != nil {
            log.Println("Failed to post alert:", err)
        } else {
            resp.Body.Close()
            fmt.Println("Posted alert for camera:", camera.Name)
        }
    }
}

func main() {
    loadEnv()
    r := gin.Default()

    // Endpoint to start dummy camera processing
    r.POST("/start", func(c *gin.Context) {
        var camera Camera
        if err := c.ShouldBindJSON(&camera); err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
            return
        }
        go simulateFaceDetection(camera)
        c.JSON(http.StatusOK, gin.H{"message": "Camera processing started"})
    })

    port := os.Getenv("PORT")
    if port == "" {
        port = "8080"
    }
    r.Run(":" + port)
}
