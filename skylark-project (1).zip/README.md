# Skylark Labs – Real-Time Multi-Camera Face Detection Dashboard (Scaffold)

This repository is a scaffold project prepared for the Skylark Labs coding test submission.
It includes `frontend`, `backend`, `worker`, and `infra` with Docker Compose and Eclipse project files.

**Note:** This scaffold is designed to be ready-to-upload. The worker is a **dummy** worker that posts fake alerts; RTSP and real face-detection are not implemented.

## Structure
```
skylark-project/
├─ frontend/
├─ backend/
├─ worker/
└─ docker-compose.yml
```

See service READMEs inside each folder for details.

