import { Hono } from 'hono'
import { prisma } from '../prismaClient'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'

const app = new Hono()

app.post('/login', async (c) => {
  const { username, password } = await c.req.json()
  const user = await prisma.user.findUnique({ where: { username } })
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return c.json({ error: 'Invalid credentials' }, 401)
  }
  const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET!, { expiresIn: '4h' })
  return c.json({ token })
})

export default app
