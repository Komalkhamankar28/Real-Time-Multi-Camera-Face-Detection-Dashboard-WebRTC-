import { Hono } from 'hono'
import { prisma } from '../prismaClient'
import { authMiddleware } from '../middleware/auth'

const app = new Hono()
app.use('*', authMiddleware)

app.get('/:cameraId', async (c) => {
  const { cameraId } = c.req.param()
  const alerts = await prisma.alert.findMany({
    where: { cameraId },
    orderBy: { timestamp: 'desc' },
    take: 10
  })
  return c.json(alerts)
})

export default app
