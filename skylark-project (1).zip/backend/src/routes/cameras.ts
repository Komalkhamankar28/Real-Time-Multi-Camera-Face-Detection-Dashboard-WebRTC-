import { Hono } from 'hono'
import { prisma } from '../prismaClient'
import { authMiddleware } from '../middleware/auth'

const app = new Hono()

app.use('*', authMiddleware)

app.get('/', async (c) => {
  const cameras = await prisma.camera.findMany()
  return c.json(cameras)
})

app.post('/', async (c) => {
  const { name, rtspUrl, location } = await c.req.json()
  const camera = await prisma.camera.create({
    data: { name, rtspUrl, location, ownerId: c.env.user.userId },
  })
  return c.json(camera)
})

export default app
