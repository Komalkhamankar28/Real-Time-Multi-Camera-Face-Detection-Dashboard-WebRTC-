import { Hono } from 'hono'
import cors from 'cors'
import authRoutes from './routes/auth'
import cameraRoutes from './routes/cameras'
import alertRoutes from './routes/alerts'

const app = new Hono()
app.use('*', cors())

app.route('/api/auth', authRoutes)
app.route('/api/cameras', cameraRoutes)
app.route('/api/alerts', alertRoutes)

const PORT = process.env.PORT || 3000
app.listen({ port: Number(PORT) })
